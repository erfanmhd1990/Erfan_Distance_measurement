import cv2 as cv
import time
import AiPhile

KNOWN_DISTANCE = 76.2  # centimeter
KNOWN_WIDTH = 14.3  # centimeter
GREEN = (0, 255, 0)
RED = (0, 0, 255)
WHITE = (255, 255, 255)
fonts = cv.FONT_HERSHEY_COMPLEX
cap = cv.VideoCapture(0)
face_detector = cv.CascadeClassifier("../haarcascade_frontalface_default.xml")

def focal_length(measured_distance, real_width, width_in_rf_image):
    
    focal_length_value = (width_in_rf_image * measured_distance) / real_width
    return focal_length_value


def distance_finder(focal_length, real_face_width, face_width_in_frame):
    
    distance = (real_face_width * focal_length) / face_width_in_frame
    return distance


def face_data(image):
    
    face_width = 0
    gray_image = cv.cvtColor(image, cv.COLOR_BGR2GRAY)
    faces = face_detector.detectMultiScale(gray_image, 1.3, 5)
    for (x, y, h, w) in faces:
        cv.rectangle(image, (x, y), (x + w, y + h), WHITE, 1)
        face_width = w

    return face_width


ref_image = cv.imread("../Ref_image.png")
ref_image_face_width = face_data(ref_image)
focal_length_found = focal_length(KNOWN_DISTANCE, KNOWN_WIDTH, ref_image_face_width)
print(focal_length_found)
cv.imshow("ref_image", ref_image)
starting_time = time.time()
frame_counter = 0
while True:
    frame_counter += 1
    _, frame = cap.read()
    face_width_in_frame = face_data(frame)
    if face_width_in_frame != 0:
        Distance = distance_finder(focal_length_found, KNOWN_WIDTH, face_width_in_frame)

        AiPhile.textBGoutline(
            frame,
            f"Distance = {round(Distance,2)} CM",
            (30, 80),
            scaling=0.5,
            text_color=AiPhile.YELLOW,
        )

    fps = frame_counter / (time.time() - starting_time)
    AiPhile.textBGoutline(frame, f"FPS: {round(fps,2)}", (30, 40), scaling=0.5)
    cv.imshow("frame", frame)
    if cv.waitKey(1) == ord("q"):
        break
cap.release()
cv.destroyAllWindows()

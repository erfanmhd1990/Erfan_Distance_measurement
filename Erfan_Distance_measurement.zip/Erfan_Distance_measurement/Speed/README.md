# Finding Speed using Distance Estimation.

![GitHub Repo stars](https://img.shields.io/github/stars/Asadullah-Dal17/Distance_measurement_using_single_camera?style=social) ![GitHub forks](https://img.shields.io/github/forks/Asadullah-Dal17/Distance_measurement_using_single_camera?style=social) ![YouTube Channel Subscribers](https://img.shields.io/youtube/channel/subscribers/UCc8Lx22a5OX4XMxrCykzjbA?style=social)

## Distance & Speed Estimation Demo

https://user-images.githubusercontent.com/66181793/122644855-bb8ac000-d130-11eb-85c3-c7ff4bd6474c.mp4

#### [Youtube Tutorial](https://youtu.be/DIxcLghsQ4Q) ![YouTube Video Views](https://img.shields.io/youtube/views/DIxcLghsQ4Q?style=social)

## TODO

- [x] Find Speed
- [x] Give it more frame to show, so it looks legible or convert the units
- [x] Youtube Tutorial: [here](https://youtu.be/DIxcLghsQ4Q) (Youtube)

#### if you want make contribution please go a head.

if any one has test this know better ways to do this please let me, or make pull request, it will be appreciated thank you.

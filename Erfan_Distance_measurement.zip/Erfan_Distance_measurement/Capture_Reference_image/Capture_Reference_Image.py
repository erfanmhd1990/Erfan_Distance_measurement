import cv2 
import time
import os

cam_number =2
camera = cv2.VideoCapture(cam_number)
starting_time =time.time()
Frame_Counter= 0
Cap_frame =0 
Dir_name = "capture_images"
number_image_captured =20
capture_image=False

while True:
    IsDirExist = os.path.exists(Dir_name)
    print(IsDirExist)
    if not IsDirExist:
        os.mkdir(Dir_name)

    Frame_Counter+=1
    ret, frame = camera.read()
    ret, saving_frame = camera.read()
    height, width, dim = saving_frame.shape
    cv2.putText(saving_frame, f"Height: {height}", (30, 50), cv2.FONT_HERSHEY_COMPLEX, 0.4, (0,255,0),1)
    cv2.putText(saving_frame, f"Width:  {width}", (30, 70), cv2.FONT_HERSHEY_COMPLEX, 0.4, (0,255,0),1)
    if capture_image==True and Cap_frame <= number_image_captured:
        Cap_frame+=1
        cv2.putText(frame, 'Capturing', (50, 70), cv2.FONT_HERSHEY_COMPLEX, 2, (0,244, 255),1)
        cv2.imwrite(f"{Dir_name}/frame-{Cap_frame}.png", saving_frame)
    else:
        cv2.putText(frame, 'Not Capturing', (50, 70), cv2.FONT_HERSHEY_COMPLEX, 2, (255,0, 255),1)
        Cap_frame =0
        capture_image =False
    cv2.imshow("frame", frame)
    cv2.imshow("saving Image", saving_frame)
    total_time = time.time()
    frame_time=total_time -starting_time

    fps = Frame_Counter/frame_time
    if cv2.waitKey(1) == ord('q'):
        break
    if cv2.waitKey(1)==ord('c'):
        capture_image= True
   
camera.release()
cv2.destroyAllWindows()